import type { Metadata } from "next";
import { Sarabun, Sora } from "next/font/google";
import "./globals.css";

const sora = Sora({
  variable: "--font-sora",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

const sarabun = Sarabun({
  variable: "--font-sarabun",
  subsets: ["thai", "latin"],
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "Area Inspection Report — Injection Production",
  description:
    "ใบรายงานการตรวจสอบพื้นที่ผลิต-ฉีด ให้คะแนน 0–10 ตามเกณฑ์ BRCGS พร้อมส่งออก Excel",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="th"
      className={`${sora.variable} ${sarabun.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
